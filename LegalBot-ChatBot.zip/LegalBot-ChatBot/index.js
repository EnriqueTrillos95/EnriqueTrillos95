const express = require('express');
const { WebhookClient } = require('dialogflow-fulfillment');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const dialogflowFulfillment = (request, response) => {
    const agent = new WebhookClient({ request, response });

    function sayHello(agent) {
        agent.add("Hi there, this response is coming from Heroku");
    }

    let intentMap = new Map();
    intentMap.set("Default Welcome Intent", sayHello);
    agent.handleRequest(intentMap);
};

app.post('/dialogflow-fulfillment', (request, response) => {
    dialogflowFulfillment(request, response);
});

app.listen(port, () => {
    console.log(`Listening on port ${port}`);
});
